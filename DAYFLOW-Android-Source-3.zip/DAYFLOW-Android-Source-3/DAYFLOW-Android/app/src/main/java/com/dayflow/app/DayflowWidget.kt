package com.dayflow.app

import android.content.Context
import androidx.glance.appwidget.updateAll
import import androidx.glance.unit.dp
import androidx.compose.runtime.Composable
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.background
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.action.ActionParameters
import androidx.glance.action.clickable
import androidx.glance.appwidget.state.updateAppWidgetState
import androidx.glance.state.PreferencesGlanceStateDefinition
import androidx.glance.layout.*
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DayflowWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = DayflowWidget()

    companion object {
        suspend fun refresh(context: Context) {
            DayflowWidget().updateAll(context)
        }

        fun update(context: Context) {
            CoroutineScope(Dispatchers.IO).launch {
                DayflowWidget().updateAll(context)
            }
        }
    }
}

class DayflowWidget : GlanceAppWidget() {

    override val stateDefinition = PreferencesGlanceStateDefinition

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent {
            val tasks = DayflowData.tasks(context).take(4)

            Column(
                GlanceModifier
                    .fillMaxSize()
                    .background(ColorProvider(android.graphics.Color.rgb(23, 31, 51)))
                    .padding(12.dp)
            ) {
                Text(
                    "DAYFLOW • TODAY",
                    style = TextStyle(
                        color = ColorProvider(android.graphics.Color.WHITE)
                    )
                )

                Spacer(GlanceModifier.height(6.dp))

                tasks.forEach { task ->
                    Row(
                        GlanceModifier
                            .fillMaxWidth()
                            .clickable(actionRunCallback<ToggleTaskAction>()),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (task.done) "✓" else "○",
                            style = TextStyle(
                                color = ColorProvider(
                                    android.graphics.Color.rgb(139, 124, 255)
                                )
                            )
                        )

                        Spacer(GlanceModifier.width(8.dp))

                        Text(
                            task.title,
                            maxLines = 1,
                            style = TextStyle(
                                color = ColorProvider(android.graphics.Color.WHITE)
                            )
                        )
                    }

                    Spacer(GlanceModifier.height(4.dp))
                }

                if (tasks.isEmpty()) {
                    Text(
                        "Add your first task",
                        style = TextStyle(
                            color = ColorProvider(android.graphics.Color.LTGRAY)
                        )
                    )
                }
            }
        }
    }
}

class ToggleTaskAction : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        val tasks = DayflowData.tasks(context)
        val index = tasks.indexOfFirst { !it.done }

        if (index >= 0) {
            tasks[index] = tasks[index].copy(done = true)
            DayflowData.saveTasks(context, tasks)
            DayflowData.addXp(context, tasks[index].xp)
        }

        DayflowWidget().update(context, glanceId)
    }
}
