package com.dayflow.app

import android.os.Bundle
import android.icu.text.SimpleDateFormat
import android.icu.util.Calendar
import android.icu.util.ULocale
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

private val bg = Color(0xFF0B1020)
private val panel = Color(0xFF171F33)
private val accent = Color(0xFF8B7CFF)
private val muted = Color(0xFF9AA8C7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DayflowScreen(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DayflowScreen(context: android.content.Context) {
    var refresh by remember { mutableIntStateOf(0) }
    var tasks by remember { mutableStateOf(DayflowData.tasks(context)) }
    var habits by remember { mutableStateOf(DayflowData.habits(context)) }
    var language by remember { mutableStateOf(DayflowData.language(context)) }
    var calendar by remember { mutableStateOf(DayflowData.calendar(context)) }
    var newTask by remember { mutableStateOf("") }
    var newHabit by remember { mutableStateOf("") }

    val fa = language == "fa"
    val xp = DayflowData.xp(context)
    val level = 1 + xp / 100

    val today = if (calendar == "jalali") {
        val locale = ULocale("fa_IR@calendar=persian")
        val formatter = SimpleDateFormat("EEEE، d MMMM yyyy", locale)
        formatter.calendar = Calendar.getInstance(locale)
        formatter.format(java.util.Date())
    } else {
        val d = LocalDate.now()
        "${d.dayOfWeek.name.lowercase().replaceFirstChar { it.uppercase() }}, ${d.dayOfMonth} ${d.month} ${d.year}"
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent,
            background = bg,
            surface = panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = bg,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("DAYFLOW", color = Color.White, letterSpacing = 3.sp)
                            Text(today, color = muted, fontSize = 12.sp)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = bg)
                )
            }
        ) { pad ->
            LazyColumn(
                Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = panel),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Column(
                            Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(if (fa) "سفر تو" else "YOUR JOURNEY", color = muted, fontSize = 12.sp)
                                    Text("LEVEL $level", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                                    Text("$xp XP", color = accent)
                                }
                                Text("✦", color = Color(0xFFFFD166), fontSize = 42.sp)
                            }

                            LinearProgressIndicator(
                                progress = { (xp % 100) / 100f },
                                modifier = Modifier.fillMaxWidth(),
                                color = accent,
                                trackColor = Color(0xFF303A55)
                            )

                            Text(
                                "${100 - xp % 100} XP ${if (fa) "تا لول بعدی" else "to next level"}",
                                color = muted,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                item {
                    SectionTitle(if (fa) "اهداف امروز" else "TODAY'S GOALS")
                }

                itemsIndexed(tasks) { i, task ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = panel),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = {
                                val updated = tasks.toMutableList()
                                val wasDone = updated[i].done
                                updated[i] = updated[i].copy(done = !wasDone)
                                tasks = updated
                                DayflowData.saveTasks(context, tasks)

                                if (!wasDone) {
                                    DayflowData.addXp(context, updated[i].xp)
                                }

                                refresh++
                                DayflowWidgetReceiver.update(context)
                            }) {
                                Icon(
                                    if (task.done) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                    null,
                                    tint = if (task.done) Color(0xFF53D6A2) else muted
                                )
                            }

                            Text(
                                task.title,
                                Modifier.weight(1f),
                                color = if (task.done) muted else Color.White
                            )
                            Text("+${task.xp} XP", color = accent, fontSize = 12.sp)
                        }
                    }
                }

                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            newTask,
                            { newTask = it },
                            Modifier.weight(1f),
                            label = { Text(if (fa) "کار جدید" else "New task") },
                            singleLine = true
                        )

                        IconButton(onClick = {
                            if (newTask.isNotBlank()) {
                                tasks = (tasks + DayTask(newTask)).toMutableList()
                                DayflowData.saveTasks(context, tasks)
                                newTask = ""
                                DayflowWidgetReceiver.update(context)
                            }
                        }) {
                            Icon(Icons.Default.Add, null, tint = accent)
                        }
                    }
                }

                item {
                    SectionTitle(if (fa) "عادت‌های من" else "MY HABITS")
                }

                itemsIndexed(habits) { i, h ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = panel),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(h.title, color = Color.White)
                                Text("${h.progress}/${h.target} ${h.unit}", color = muted, fontSize = 12.sp)
                            }

                            LinearProgressIndicator(
                                progress = {
                                    (h.progress.toFloat() / h.target.coerceAtLeast(1)).coerceIn(0f, 1f)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                color = Color(0xFF4CC9F0)
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {
                                    habits = habits.toMutableList().also {
                                        it[i] = h.copy(progress = (h.progress - 1).coerceAtLeast(0))
                                    }
                                    DayflowData.saveHabits(context, habits)
                                }) {
                                    Text("−")
                                }

                                OutlinedButton(onClick = {
                                    habits = habits.toMutableList().also {
                                        it[i] = h.copy(progress = (h.progress + 1).coerceAtMost(h.target))
                                    }
                                    DayflowData.saveHabits(context, habits)
                                    DayflowData.addXp(context, 5)
                                }) {
                                    Text("+")
                                }
                            }
                        }
                    }
                }

                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            newHabit,
                            { newHabit = it },
                            Modifier.weight(1f),
                            label = { Text(if (fa) "نام عادت جدید" else "New habit") },
                            singleLine = true
                        )

                        IconButton(onClick = {
                            if (newHabit.isNotBlank()) {
                                habits = (habits + Habit(
                                    newHabit,
                                    1,
                                    if (fa) "بار" else "times"
                                )).toMutableList()

                                DayflowData.saveHabits(context, habits)
                                newHabit = ""
                            }
                        }) {
                            Icon(Icons.Default.Add, null, tint = accent)
                        }
                    }
                }

                item {
                    SectionTitle(if (fa) "تنظیمات" else "SETTINGS")
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = panel),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(if (fa) "زبان" else "Language", color = muted)

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = fa,
                                    onClick = {
                                        language = "fa"
                                        DayflowData.setLanguage(context, "fa")
                                    },
                                    label = { Text("فارسی") }
                                )

                                FilterChip(
                                    selected = !fa,
                                    onClick = {
                                        language = "en"
                                        DayflowData.setLanguage(context, "en")
                                    },
                                    label = { Text("English") }
                                )
                            }

                            Text(if (fa) "تقویم" else "Calendar", color = muted)

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = calendar == "jalali",
                                    onClick = {
                                        calendar = "jalali"
                                        DayflowData.setCalendar(context, "jalali")
                                    },
                                    label = { Text("شمسی") }
                                )

                                FilterChip(
                                    selected = calendar == "gregorian",
                                    onClick = {
                                        calendar = "gregorian"
                                        DayflowData.setCalendar(context, "gregorian")
                                    },
                                    label = { Text("Gregorian") }
                                )
                            }
                        }
                    }
                }

                item {
                    Spacer(Modifier.height(28.dp))
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(s: String) {
    Text(
        s,
        color = muted,
        style = MaterialTheme.typography.titleSmall,
        letterSpacing = 1.5.sp
    )
}