package com.dayflow.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class DayTask(val title: String, val done: Boolean = false, val xp: Int = 10)
data class Habit(val title: String, val target: Int, val unit: String, val progress: Int = 0)

object DayflowData {
    private const val PREF = "dayflow_data"
    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun tasks(c: Context): MutableList<DayTask> {
        val a = JSONArray(prefs(c).getString("tasks", "[]"))
        return MutableList(a.length()) { i ->
            val o = a.getJSONObject(i); DayTask(o.optString("title"), o.optBoolean("done"), o.optInt("xp", 10))
        }
    }
    fun saveTasks(c: Context, list: List<DayTask>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("title", it.title).put("done", it.done).put("xp", it.xp)) }
        prefs(c).edit().putString("tasks", a.toString()).apply()
    }
    fun habits(c: Context): MutableList<Habit> {
        val a = JSONArray(prefs(c).getString("habits", """[{"title":"نوشیدن آب","target":8,"unit":"لیوان","progress":0},{"title":"خواب کافی","target":8,"unit":"ساعت","progress":0}]"""))
        return MutableList(a.length()) { i ->
            val o = a.getJSONObject(i); Habit(o.optString("title"), o.optInt("target", 1), o.optString("unit"), o.optInt("progress", 0))
        }
    }
    fun saveHabits(c: Context, list: List<Habit>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("title", it.title).put("target", it.target).put("unit", it.unit).put("progress", it.progress)) }
        prefs(c).edit().putString("habits", a.toString()).apply()
    }
    fun xp(c: Context) = prefs(c).getInt("xp", 0)
    fun addXp(c: Context, n: Int) { prefs(c).edit().putInt("xp", xp(c) + n).apply() }
    fun language(c: Context) = prefs(c).getString("language", "fa") ?: "fa"
    fun setLanguage(c: Context, v: String) { prefs(c).edit().putString("language", v).apply() }
    fun calendar(c: Context) = prefs(c).getString("calendar", "jalali") ?: "jalali"
    fun setCalendar(c: Context, v: String) { prefs(c).edit().putString("calendar", v).apply() }
}
